package com.example.radiotest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

public class BroadcastReceiverr extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i("tagggggg", "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb" );
        Intent i = new Intent(context, ServiceName.class);
        context.startService(i);

        if (intent != null) {
            String action = intent.getAction();

            switch (action) {
                case Intent.ACTION_BOOT_COMPLETED:
                    System.out.println("Called on REBOOT");
                    // start a new service
                    context.startService(intent);
                    Toast.makeText(context, "dupa INTENTTTTTTTTT", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    Toast.makeText(context, "nnnnnnnnnnnnnnnnnnnnnnnnnn INTENTTTTTTTTT", Toast.LENGTH_SHORT).show();
                    break;
            }
        }

        if (isAirplaneModeOn(context.getApplicationContext())) {
            Toast.makeText(context, "AirPlane mode is on", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "AirPlane mode is off", Toast.LENGTH_SHORT).show();
        }
    }

    private static boolean isAirplaneModeOn(Context context) {
        return Settings.System.getInt(context.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0;
    }

}
