package com.example.radiotest;

import android.animation.Animator;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class ExampleService  extends Service {
    MediaPlayer player = new MediaPlayer();
    public static final String  CHANNEL_ID ="exampleServiceChannel";
    private NotificationCompat.Builder notificationBuilder =  new NotificationCompat.Builder(this, "exampleServiceChannel");
    private static MediaSession mediaSession;
    private  PlaybackState.Builder stateBuilder;
    private NotificationManager notificationManager;

    @Override
    public void onCreate() {
        super.onCreate();


    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String input = intent.getStringExtra("inputExtra");
        Intent notificationIntent = new Intent(this, MainActivity.class );
        PendingIntent pendingIntent =  PendingIntent.getActivity(this, 0, notificationIntent,PendingIntent.FLAG_IMMUTABLE);
        Notification notification = notificationBuilder
                .setContentTitle("VOCEA CRESTINILOR")
                .setContentText("radio")
                .setSmallIcon(R.drawable.ic_android)
                .setContentIntent(pendingIntent)
                .addAction(R.drawable.ic_android, "Like",pendingIntent)
                .build();
        startForeground(1, notification);
        player = MediaPlayer.create(this, Uri.parse("http://asculta.radiocnm.ro:8002/live"));
        startForeground(1, notification);
        player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

            @Override
            public void onPrepared(MediaPlayer mp) {
                Log.e("tah", "pregatit de PLAY" );
                mp.start();


            }
        });
        CreateMediaSession();
        return START_NOT_STICKY;

    }

    private void CreateMediaSession(){
        mediaSession = new MediaSession(this, "simpleplayer session");
        Log.e("STOP", "STOOOOOOOOP" );
        stateBuilder = new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY |
                                PlaybackState.ACTION_PAUSE |
                                PlaybackState.ACTION_STOP
                        );

        mediaSession.setPlaybackState(stateBuilder.build());
        mediaSession.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                super.onPlay();
                player.start();
            }
            @Override
            public void onPause() {
                super.onPause();
                player.pause();

            }
            @Override
            public void onStop() {

            }
        });
        mediaSession.setActive(true);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        player.stop();
        Log.e("STOP", "STOOOOOOOOP" );
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    private void showNotification(){
int icon;
String playPause;
if (player.isPlaying()){
    icon = R.drawable.ic_pause;
    playPause = "Pause";
}
else
{
    icon = R.drawable.ic_pause;
    playPause = "Play";
}
NotificationCompat.Action playPauseAction = new NotificationCompat.Action(icon, playPause,
        MediaButtonReceiver.build
        )

    }
}
